package com.alyndroid.architecturepatternstutorialshomework;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.alyndroid.architecturepatternstutorialshomework.model.AdditionModel;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
//    ActivityMainBinding binding;
    TextView plusResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main);
        binding.setAdditionModel();
        binding.setLifecycleOwner(this);
        binding.plusButton.setOnClickListener(this);*/
        Button plus = findViewById(R.id.plus_button);
        plusResult = findViewById(R.id.plus_result_textView);
        plus.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.plus_button:
                plusResult.setText(new AdditionModel(new DataBase().getNumbers()).add());
        }
    }
}
