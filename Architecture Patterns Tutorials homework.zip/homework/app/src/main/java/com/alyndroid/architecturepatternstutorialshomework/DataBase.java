package com.alyndroid.architecturepatternstutorialshomework;

public class DataBase {
    public NumberModel getNumbers(){
        return new NumberModel(4, 2);
    }
}
